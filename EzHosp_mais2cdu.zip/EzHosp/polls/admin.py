from django.contrib import admin
from polls.models import Patient
# Register your models here.

admin.site.register(Patient)