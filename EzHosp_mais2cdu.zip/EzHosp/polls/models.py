from django.core.validators import RegexValidator
from django.core.urlresolvers import reverse
from django.db import models


# Create your models here.

class Patient(models.Model):
	firstName = models.CharField(max_length=50)
	lastName = models.CharField(max_length=50)
	email = models.CharField(max_length=50)
	phone = models.CharField(max_length=15)
	cellPhone = models.CharField(max_length=15)
	city = models.CharField(max_length=20)
	address = models.CharField(max_length=30)
	street = models.CharField(max_length=20)
	login = models.CharField(max_length=20)
	password = models.CharField(max_length=20)

class Convenio(models.Model):
	firstName = models.CharField(max_length=50)
	fantasyName = models.CharField(max_length=50)
	email = models.CharField(max_length=50)
	phone = models.CharField(max_length=15)
	login = models.CharField(max_length=20)
	password = models.CharField(max_length=20)

class Hospital(models.Model):
	nome = models.CharField(max_length=50)
	cnpj = models.CharField(max_length=50)
	email = models.CharField(max_length=50)
	telefone = models.CharField(max_length=15)
	estado = models.CharField(max_length=20)
	cidade = models.CharField(max_length=20)
	bairro = models.CharField(max_length=30)
	rua = models.CharField(max_length=20)
	planoSaude = models.CharField(max_length=80)
	login = models.CharField(max_length=20)
	password = models.CharField(max_length=20)

class Exame(models.Model):
	nome = models.CharField(max_length=50)
